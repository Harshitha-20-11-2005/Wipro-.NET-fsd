﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter a string: ");
        string str = Console.ReadLine();

        int alphabets = 0, digits = 0;

        foreach (char ch in str)
        {
            if (char.IsLetter(ch))
                alphabets++;
            else if (char.IsDigit(ch))
                digits++;
        }

        Console.WriteLine("Alphabets = " + alphabets);
        Console.WriteLine("Digits = " + digits);
    }
}

