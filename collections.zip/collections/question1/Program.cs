﻿using System;
using System.Collections;

class Employee
{
    public string EmployeeName { get; set; }
    public int EmployeeID { get; set; }
    public double Salary { get; set; }

    public Employee(string name, int id, double salary)
    {
        EmployeeName = name;
        EmployeeID = id;
        Salary = salary;
    }
}

class EmployeeDAL
{
    private ArrayList employees = new ArrayList();

    // Add Employee
    public void AddEmployee(Employee e)
    {
        employees.Add(e);
        Console.WriteLine("Employee Added Successfully.");
    }

    // Delete Employee
    public bool DeleteEmployee(int id)
    {
        foreach (Employee emp in employees)
        {
            if (emp.EmployeeID == id)
            {
                employees.Remove(emp);
                return true;
            }
        }

        return false;
    }

    // Search Employee
    public string SearchEmployee(int id)
    {
        foreach (Employee emp in employees)
        {
            if (emp.EmployeeID == id)
            {
                return emp.EmployeeName;
            }
        }

        return null;
    }

    // Get All Employees
    public Employee[] GetAllEmployees()
    {
        Employee[] empArray = new Employee[employees.Count];

        for (int i = 0; i < employees.Count; i++)
        {
            empArray[i] = (Employee)employees[i];
        }

        return empArray;
    }
}

class Program
{
    static void Main(string[] args)
    {
        EmployeeDAL empDAL = new EmployeeDAL();

        // Adding Employees
        empDAL.AddEmployee(new Employee("Harshi", 101, 50000));
        empDAL.AddEmployee(new Employee("Ravi", 102, 45000));
        empDAL.AddEmployee(new Employee("Priya", 103, 60000));

        Console.WriteLine();

        // Search Employee
        Console.Write("Enter Employee ID to Search: ");
        int searchId = Convert.ToInt32(Console.ReadLine());

        string name = empDAL.SearchEmployee(searchId);

        if (name != null)
            Console.WriteLine("Employee Found : " + name);
        else
            Console.WriteLine("Employee Not Found");

        Console.WriteLine();

        // Delete Employee
        Console.Write("Enter Employee ID to Delete: ");
        int deleteId = Convert.ToInt32(Console.ReadLine());

        if (empDAL.DeleteEmployee(deleteId))
            Console.WriteLine("Employee Deleted Successfully.");
        else
            Console.WriteLine("Employee Not Found.");

        Console.WriteLine();

        // Display All Employees
        Console.WriteLine("Employee Details");
        Console.WriteLine("-----------------------------");

        Employee[] employees = empDAL.GetAllEmployees();

        foreach (Employee emp in employees)
        {
            Console.WriteLine("ID     : " + emp.EmployeeID);
            Console.WriteLine("Name   : " + emp.EmployeeName);
            Console.WriteLine("Salary : " + emp.Salary);
            Console.WriteLine("-----------------------------");
        }
    }
}