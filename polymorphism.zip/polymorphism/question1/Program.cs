﻿using System;

class Area
{
    // Circle
    public double CalculateArea(double radius)
    {
        return 3.14 * radius * radius;
    }

    // Rectangle
    public double CalculateArea(double length, double breadth)
    {
        return length * breadth;
    }

    // Triangle
    public double CalculateArea(double baseValue, double height, bool triangle)
    {
        return 0.5 * baseValue * height;
    }
}

class Program
{
    static void Main()
    {
        Area obj = new Area();

        Console.Write("Enter radius: ");
        double r = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Area of Circle = " + obj.CalculateArea(r));

        Console.Write("\nEnter length: ");
        double l = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter breadth: ");
        double b = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Area of Rectangle = " + obj.CalculateArea(l, b));

        Console.Write("\nEnter base: ");
        double ba = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter height: ");
        double h = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Area of Triangle = " + obj.CalculateArea(ba, h, true));
    }
}