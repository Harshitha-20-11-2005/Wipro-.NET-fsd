﻿using System;

class MyMath
{
    // Add
    public int Add(int a, int b)
    {
        return a + b;
    }

    public int Add(int a, int b, int c)
    {
        return a + b + c;
    }

    // Subtract
    public int Subtract(int a, int b)
    {
        return a - b;
    }

    public int Subtract(int a, int b, int c)
    {
        return a - b - c;
    }

    // Multiply
    public int Multiply(int a, int b)
    {
        return a * b;
    }

    public int Multiply(int a, int b, int c)
    {
        return a * b * c;
    }

    // Divide
    public int Divide(int a, int b)
    {
        return a / b;
    }

    public int Divide(int a, int b, int c)
    {
        return (a / b) / c;
    }
}

class Program
{
    static void Main()
    {
        MyMath math = new MyMath();

        Console.WriteLine("Add(10,20) = " + math.Add(10,20));
        Console.WriteLine("Add(10,20,30) = " + math.Add(10,20,30));

        Console.WriteLine("Subtract(20,10) = " + math.Subtract(20,10));
        Console.WriteLine("Subtract(30,10,5) = " + math.Subtract(30,10,5));

        Console.WriteLine("Multiply(10,20) = " + math.Multiply(10,20));
        Console.WriteLine("Multiply(2,3,4) = " + math.Multiply(2,3,4));

        Console.WriteLine("Divide(20,5) = " + math.Divide(20,5));
        Console.WriteLine("Divide(100,5,2) = " + math.Divide(100,5,2));
    }
}