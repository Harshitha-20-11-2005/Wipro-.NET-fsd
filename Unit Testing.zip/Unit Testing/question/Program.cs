﻿using System;

namespace CalculatorApp
{
    class Calculator
    {
        public double Add(double a, double b)
        {
            return a + b;
        }

        public double Subtract(double a, double b)
        {
            return a - b;
        }

        public double Multiply(double a, double b)
        {
            return a * b;
        }

        public double Divide(double a, double b)
        {
            if (b == 0)
            {
                Console.WriteLine("Error! Division by zero is not allowed.");
                return 0;
            }

            return a / b;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Calculator cal = new Calculator();

            int choice;
            double num1, num2;

            do
            {
                Console.WriteLine("\n******** CALCULATOR ********");
                Console.WriteLine("1. Addition");
                Console.WriteLine("2. Subtraction");
                Console.WriteLine("3. Multiplication");
                Console.WriteLine("4. Division");
                Console.WriteLine("5. Exit");

                Console.Write("Enter your choice: ");
                choice = Convert.ToInt32(Console.ReadLine());

                if (choice >= 1 && choice <= 4)
                {
                    Console.Write("Enter First Number: ");
                    num1 = Convert.ToDouble(Console.ReadLine());

                    Console.Write("Enter Second Number: ");
                    num2 = Convert.ToDouble(Console.ReadLine());
                }
                else
                {
                    num1 = num2 = 0;
                }

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Result = " + cal.Add(num1, num2));
                        break;

                    case 2:
                        Console.WriteLine("Result = " + cal.Subtract(num1, num2));
                        break;

                    case 3:
                        Console.WriteLine("Result = " + cal.Multiply(num1, num2));
                        break;

                    case 4:
                        Console.WriteLine("Result = " + cal.Divide(num1, num2));
                        break;

                    case 5:
                        Console.WriteLine("Thank You!");
                        break;

                    default:
                        Console.WriteLine("Invalid Choice!");
                        break;
                }

            } while (choice != 5);
        }
    }
}