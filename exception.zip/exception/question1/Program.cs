﻿using System;

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("Enter Student Name: ");
            string name = Console.ReadLine();

            int[] marks = new int[3];

            for (int i = 0; i < 3; i++)
            {
                Console.Write("Enter Marks of Subject " + (i + 1) + ": ");
                marks[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("\nStudent Name : " + name);
            Console.WriteLine("Marks:");

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Subject " + (i + 1) + " : " + marks[i]);
            }
        }
        catch (FormatException)
        {
            Console.WriteLine("Error: Please enter only integer values for marks.");
        }
    }
}