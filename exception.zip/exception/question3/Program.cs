﻿using System;

class Person
{
    public string FirstName;
    public string LastName;
    public DateTime DOB;

    public Person(string firstName, string lastName, DateTime dob)
    {
        if (dob > DateTime.Now)
            throw new Exception("Date of Birth cannot be in the future.");

        FirstName = firstName;
        LastName = lastName;
        DOB = dob;
    }

    public void Display()
    {
        Console.WriteLine("Name : " + FirstName + " " + LastName);
        Console.WriteLine("DOB  : " + DOB.ToShortDateString());
    }
}

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("First Name: ");
            string first = Console.ReadLine();

            Console.Write("Last Name: ");
            string last = Console.ReadLine();

            Console.Write("DOB (dd/mm/yyyy): ");
            DateTime dob = DateTime.Parse(Console.ReadLine());

            Person p = new Person(first, last, dob);

            p.Display();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}