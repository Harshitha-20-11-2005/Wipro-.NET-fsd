﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter num1: ");
        int num1 = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter num2: ");
        int num2 = Convert.ToInt32(Console.ReadLine());

        // Pre-increment
        num2 = ++num1;
        Console.WriteLine("\nAfter Pre-Increment:");
        Console.WriteLine("num1 = " + num1);
        Console.WriteLine("num2 = " + num2);

        // Reset values
        Console.Write("\nEnter num1 again: ");
        num1 = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter num2 again: ");
        num2 = Convert.ToInt32(Console.ReadLine());

        // Post-increment
        num2 = num1++;
        Console.WriteLine("\nAfter Post-Increment:");
        Console.WriteLine("num1 = " + num1);
        Console.WriteLine("num2 = " + num2);

        // Swap
        int temp = num1;
        num1 = num2;
        num2 = temp;

        Console.WriteLine("\nAfter Swapping:");
        Console.WriteLine("num1 = " + num1);
        Console.WriteLine("num2 = " + num2);
    }
}