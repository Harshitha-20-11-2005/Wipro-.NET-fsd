﻿using System;

namespace DelegateDemo
{
    
    public delegate double MathOperation(double a, double b);

    
    class Calculator
    {
        public double Add(double a, double b)
        {
            return a + b;
        }

        public double Subtract(double a, double b)
        {
            return a - b;
        }

        public double Multiply(double a, double b)
        {
            return a * b;
        }

        public double Divide(double a, double b)
        {
            if (b == 0)
            {
                Console.WriteLine("Division by zero is not allowed.");
                return 0;
            }
            return a / b;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Calculator cal = new Calculator();

            Console.Write("Enter First Number: ");
            double num1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter Second Number: ");
            double num2 = Convert.ToDouble(Console.ReadLine());

            
            MathOperation operation;

            
            operation = cal.Add;
            Console.WriteLine("Addition = " + operation(num1, num2));

            
            operation = cal.Subtract;
            Console.WriteLine("Subtraction = " + operation(num1, num2));

            
            operation = cal.Multiply;
            Console.WriteLine("Multiplication = " + operation(num1, num2));

            // Division
            operation = cal.Divide;
            Console.WriteLine("Division = " + operation(num1, num2));
        }
    }
}