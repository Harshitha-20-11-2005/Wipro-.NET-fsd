﻿using System;
using System.Collections;

class Employee
{
    public string EmployeeName { get; set; }
    public int EmployeeID { get; set; }
    public double Salary { get; set; }

    public Employee(string name, int id, double salary)
    {
        EmployeeName = name;
        EmployeeID = id;
        Salary = salary;
    }
}

class EmployeeDAL
{
    SortedList employees = new SortedList();

    public void AddEmployee(Employee e)
    {
        if (!employees.ContainsKey(e.EmployeeID))
        {
            employees.Add(e.EmployeeID, e);
            Console.WriteLine("Employee Added");
        }
        else
        {
            Console.WriteLine("Employee ID already exists");
        }
    }

    public bool DeleteEmployee(int id)
    {
        if (employees.ContainsKey(id))
        {
            employees.Remove(id);
            return true;
        }
        return false;
    }

    public string SearchEmployee(int id)
    {
        if (employees.ContainsKey(id))
        {
            Employee emp = (Employee)employees[id];
            return emp.EmployeeName;
        }

        return null;
    }

    public Employee[] GetAllEmployees()
    {
        Employee[] arr = new Employee[employees.Count];

        int i = 0;
        foreach (DictionaryEntry item in employees)
        {
            arr[i++] = (Employee)item.Value;
        }

        return arr;
    }
}

class Program
{
    static void Main()
    {
        EmployeeDAL dal = new EmployeeDAL();

        dal.AddEmployee(new Employee("Harshi",101,50000));
        dal.AddEmployee(new Employee("Ravi",102,45000));
        dal.AddEmployee(new Employee("Priya",103,60000));

        Console.WriteLine();

        Console.Write("Search ID : ");
        int id = Convert.ToInt32(Console.ReadLine());

        string name = dal.SearchEmployee(id);

        if(name!=null)
            Console.WriteLine("Employee : "+name);
        else
            Console.WriteLine("Not Found");

        Console.WriteLine();

        Console.Write("Delete ID : ");
        id=Convert.ToInt32(Console.ReadLine());

        if(dal.DeleteEmployee(id))
            Console.WriteLine("Deleted");
        else
            Console.WriteLine("Employee Not Found");

        Console.WriteLine();

        Employee[] list=dal.GetAllEmployees();

        foreach(Employee e in list)
        {
            Console.WriteLine(e.EmployeeID+" "+e.EmployeeName+" "+e.Salary);
        }
    }
}