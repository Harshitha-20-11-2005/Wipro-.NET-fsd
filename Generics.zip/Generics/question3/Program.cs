﻿using System;
using System.Collections.Generic;
using System.IO;

namespace EmployeeCSV
{
    
    class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Designation { get; set; }
        public DateTime JoiningDate { get; set; }
        public string DepartmentName { get; set; }
    }

    
    class EmployeeData
    {
        public List<Employee> EmployeeInfo { get; set; }

        public EmployeeData()
        {
            EmployeeInfo = new List<Employee>();
        }

        
        public void ReadAndStoreEmployeeData()
        {
            Employee emp = new Employee();

            Console.Write("Enter Employee ID: ");
            emp.EmployeeID = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Employee Name: ");
            emp.EmployeeName = Console.ReadLine();

            Console.Write("Enter Designation: ");
            emp.Designation = Console.ReadLine();

            Console.Write("Enter Joining Date (dd/MM/yyyy): ");
            emp.JoiningDate = Convert.ToDateTime(Console.ReadLine());

            Console.Write("Enter Department Name: ");
            emp.DepartmentName = Console.ReadLine();

            
            EmployeeInfo.Add(emp);

            string filePath = "EmployeeData.csv";

            
            if (!File.Exists(filePath))
            {
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    sw.WriteLine("EmployeeID,EmployeeName,Designation,JoiningDate,DepartmentName");
                }
            }

            
            using (StreamWriter sw = new StreamWriter(filePath, true))
            {
                foreach (Employee e in EmployeeInfo)
                {
                    sw.WriteLine($"{e.EmployeeID},{e.EmployeeName},{e.Designation},{e.JoiningDate:dd/MM/yyyy},{e.DepartmentName}");
                }
            }

            Console.WriteLine("\nEmployee details stored successfully in EmployeeData.csv");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            EmployeeData employeeData = new EmployeeData();

            employeeData.ReadAndStoreEmployeeData();

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}