﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TokenManagementSystem
{
    
    class ServiceToken
    {
        private static int Counter = 1;

        public int TokenID { get; set; }
        public int Position { get; set; }
        public DateTime TicketDateTime { get; set; }
        public string Status { get; set; }

        
        public ServiceToken(int position, DateTime ticketDateTime, string status)
        {
            TokenID = Counter++;
            Position = position;
            TicketDateTime = ticketDateTime;
            Status = status;
        }
    }

    
    class TicketManager
    {
        public Queue<ServiceToken> Queue { get; set; }

        public TicketManager()
        {
            Queue = new Queue<ServiceToken>();
        }

        
        public void GenerateServiceToken()
        {
            int position = Queue.Count + 1;

            ServiceToken token = new ServiceToken(position, DateTime.Now, "Pending");

            Queue.Enqueue(token);

            Console.WriteLine("\nToken Generated Successfully.");
            Console.WriteLine("Token ID : " + token.TokenID);
        }

        
        public void GetNextToken()
        {
            if (Queue.Count == 0)
            {
                Console.WriteLine("\nNo Tokens Available.");
                return;
            }

            ServiceToken token = Queue.Peek();

            Console.WriteLine("\nNext Token Details");
            Console.WriteLine("Token ID : " + token.TokenID);
            Console.WriteLine("Position : " + token.Position);
            Console.WriteLine("Date     : " + token.TicketDateTime);
            Console.WriteLine("Status   : " + token.Status);
        }

        
        public void UpdateToken(int tokenID)
        {
            bool found = false;

            foreach (ServiceToken token in Queue)
            {
                if (token.TokenID == tokenID)
                {
                    token.Status = "Completed";
                    found = true;
                    Console.WriteLine("\nToken Updated Successfully.");
                    break;
                }
            }

            if (!found)
                Console.WriteLine("\nToken Not Found.");
        }

        
        public void SkipToken()
        {
            if (Queue.Count < 2)
            {
                Console.WriteLine("\nNot enough tokens to skip.");
                return;
            }

            ServiceToken skipped = Queue.Dequeue();

            Queue.Enqueue(skipped);

            Console.WriteLine("\nSkipped Token ID : " + skipped.TokenID);

            Console.WriteLine("Next Token is : " + Queue.Peek().TokenID);
        }

        
        public void ListAllTokens()
        {
            if (Queue.Count == 0)
            {
                Console.WriteLine("\nNo Tokens Available.");
                return;
            }

            Console.WriteLine("\n-------------------------------");
            foreach (ServiceToken token in Queue)
            {
                Console.WriteLine("Token ID : " + token.TokenID);
                Console.WriteLine("Position : " + token.Position);
                Console.WriteLine("Date     : " + token.TicketDateTime);
                Console.WriteLine("Status   : " + token.Status);
                Console.WriteLine("-------------------------------");
            }
        }
    }

    
    class Program
    {
        static void Main(string[] args)
        {
            TicketManager manager = new TicketManager();

            int choice;

            do
            {
                Console.WriteLine("\n******** TOKEN MANAGEMENT SYSTEM ********");
                Console.WriteLine("1. Create Token");
                Console.WriteLine("2. Get Next Token");
                Console.WriteLine("3. Update Token");
                Console.WriteLine("4. Skip Token");
                Console.WriteLine("5. List All Tokens");
                Console.WriteLine("6. Exit");

                Console.Write("\nEnter your Choice: ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        manager.GenerateServiceToken();
                        break;

                    case 2:
                        manager.GetNextToken();
                        break;

                    case 3:
                        Console.Write("Enter Token ID: ");
                        int id = Convert.ToInt32(Console.ReadLine());
                        manager.UpdateToken(id);
                        break;

                    case 4:
                        manager.SkipToken();
                        break;

                    case 5:
                        manager.ListAllTokens();
                        break;

                    case 6:
                        Console.WriteLine("Exiting Application...");
                        break;

                    default:
                        Console.WriteLine("Invalid Choice.");
                        break;
                }

            } while (choice != 6);
        }
    }
}