﻿using System;

class Person
{
    private string firstName;
    private string lastName;
    private string emailAddress;
    private DateTime dateOfBirth;

    public Person(string firstName, string lastName, string emailAddress, DateTime dateOfBirth)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAddress = emailAddress;
        this.dateOfBirth = dateOfBirth;
    }

    // Read-only Property
    public bool IsAdult
    {
        get
        {
            int age = DateTime.Now.Year - dateOfBirth.Year;
            if (dateOfBirth > DateTime.Now.AddYears(-age))
                age--;

            return age >= 18;
        }
    }

    public string SunSign
    {
        get
        {
            int day = dateOfBirth.Day;
            int month = dateOfBirth.Month;

            if ((month == 3 && day >= 21) || (month == 4 && day <= 19))
                return "Aries";
            else if ((month == 4 && day >= 20) || (month == 5 && day <= 20))
                return "Taurus";
            else if ((month == 5 && day >= 21) || (month == 6 && day <= 20))
                return "Gemini";
            else if ((month == 6 && day >= 21) || (month == 7 && day <= 22))
                return "Cancer";
            else if ((month == 7 && day >= 23) || (month == 8 && day <= 22))
                return "Leo";
            else if ((month == 8 && day >= 23) || (month == 9 && day <= 22))
                return "Virgo";
            else if ((month == 9 && day >= 23) || (month == 10 && day <= 22))
                return "Libra";
            else if ((month == 10 && day >= 23) || (month == 11 && day <= 21))
                return "Scorpio";
            else if ((month == 11 && day >= 22) || (month == 12 && day <= 21))
                return "Sagittarius";
            else if ((month == 12 && day >= 22) || (month == 1 && day <= 19))
                return "Capricorn";
            else if ((month == 1 && day >= 20) || (month == 2 && day <= 18))
                return "Aquarius";
            else
                return "Pisces";
        }
    }

    public bool IsBirthDay
    {
        get
        {
            return DateTime.Now.Month == dateOfBirth.Month &&
                   DateTime.Now.Day == dateOfBirth.Day;
        }
    }

    public string ScreenName
    {
        get
        {
            return firstName.ToLower() + lastName.ToLower() + dateOfBirth.Year;
        }
    }

    public void Display()
    {
        Console.WriteLine("\nPerson Details");
        Console.WriteLine("-------------------------");
        Console.WriteLine("First Name : " + firstName);
        Console.WriteLine("Last Name  : " + lastName);
        Console.WriteLine("Email      : " + emailAddress);
        Console.WriteLine("DOB        : " + dateOfBirth.ToShortDateString());

        Console.WriteLine("\nComputed Properties");
        Console.WriteLine("-------------------------");
        Console.WriteLine("Is Adult   : " + IsAdult);
        Console.WriteLine("Sun Sign   : " + SunSign);
        Console.WriteLine("Birthday Today : " + IsBirthDay);
        Console.WriteLine("Screen Name : " + ScreenName);
    }
}

class Employee : Person
{
    public double Salary { get; set; }

    public Employee(string firstName, string lastName,
                    string email, DateTime dob, double salary)
        : base(firstName, lastName, email, dob)
    {
        Salary = salary;
    }

    public void DisplayEmployee()
    {
        Display();
        Console.WriteLine("Salary : " + Salary);
    }
}

class Program
{
    static void Main()
    {
        Console.Write("First Name: ");
        string first = Console.ReadLine();

        Console.Write("Last Name: ");
        string last = Console.ReadLine();

        Console.Write("Email: ");
        string email = Console.ReadLine();

        Console.Write("Date of Birth (dd/mm/yyyy): ");
        DateTime dob = DateTime.Parse(Console.ReadLine());

        Console.Write("Salary: ");
        double salary = Convert.ToDouble(Console.ReadLine());

        Employee emp = new Employee(first, last, email, dob, salary);

        emp.DisplayEmployee();
    }
}