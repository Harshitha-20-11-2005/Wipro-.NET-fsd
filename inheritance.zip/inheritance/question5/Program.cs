﻿using System;

interface IPayable
{
    double CalculatePay();
}

class Person
{
    public string FirstName;
    public string LastName;

    public Person(string firstName, string lastName)
    {
        FirstName = firstName;
        LastName = lastName;
    }

    public void Display()
    {
        Console.WriteLine("Employee Name : " + FirstName + " " + LastName);
    }
}

class HourlyEmployee : Person, IPayable
{
    public double HoursWorked;
    public double PayPerHour;

    public HourlyEmployee(string firstName, string lastName,
                          double hoursWorked, double payPerHour)
        : base(firstName, lastName)
    {
        HoursWorked = hoursWorked;
        PayPerHour = payPerHour;
    }

    public double CalculatePay()
    {
        return HoursWorked * PayPerHour;
    }
}

class PermanentEmployee : Person, IPayable
{
    public double BasicSalary;

    public PermanentEmployee(string firstName, string lastName,
                             double basicSalary)
        : base(firstName, lastName)
    {
        BasicSalary = basicSalary;
    }

    public double CalculatePay()
    {
        double hra = BasicSalary * 0.15;
        double da = BasicSalary * 0.10;
        double grossPay = BasicSalary + hra + da;
        double tax = grossPay * 0.08;

        return grossPay - tax;
    }
}

class Program
{
    static void Main()
    {
        IPayable emp1 = new HourlyEmployee("Harshi", "K", 40, 500);
        IPayable emp2 = new PermanentEmployee("Harshi", "K", 50000);

        Console.WriteLine("Hourly Employee Pay : " + emp1.CalculatePay());
        Console.WriteLine("Permanent Employee Net Pay : " + emp2.CalculatePay());
    }
}