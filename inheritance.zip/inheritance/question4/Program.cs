﻿using System;

interface IPayable
{
    double CalculatePay();
}

class HourlyEmployee : IPayable
{
    public double HoursWorked;
    public double PayPerHour;

    public HourlyEmployee(double hoursWorked, double payPerHour)
    {
        HoursWorked = hoursWorked;
        PayPerHour = payPerHour;
    }

    public double CalculatePay()
    {
        return HoursWorked * PayPerHour;
    }
}

class PermanentEmployee : IPayable
{
    public double BasicSalary;

    public PermanentEmployee(double basicSalary)
    {
        BasicSalary = basicSalary;
    }

    public double CalculatePay()
    {
        double hra = BasicSalary * 0.15;
        double da = BasicSalary * 0.10;
        double totalPay = BasicSalary + hra + da;
        double tax = totalPay * 0.08;

        return totalPay - tax;
    }
}

class Program
{
    static void Main()
    {
        HourlyEmployee h = new HourlyEmployee(40, 500);
        PermanentEmployee p = new PermanentEmployee(50000);

        Console.WriteLine("Hourly Employee Pay : " + h.CalculatePay());
        Console.WriteLine("Permanent Employee Net Pay : " + p.CalculatePay());
    }
}