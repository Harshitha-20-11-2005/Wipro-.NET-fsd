﻿using System;

interface IPayable
{
    double CalculatePay();
}

class Person
{
    public string FirstName;
    public string LastName;

    public Person(string firstName, string lastName)
    {
        FirstName = firstName;
        LastName = lastName;
    }

    public void Display()
    {
        Console.WriteLine("Name : " + FirstName + " " + LastName);
    }
}

class HourlyEmployee : Person, IPayable
{
    public double HoursWorked;
    public double PayPerHour;

    public HourlyEmployee(string firstName, string lastName,
                          double hoursWorked, double payPerHour)
        : base(firstName, lastName)
    {
        HoursWorked = hoursWorked;
        PayPerHour = payPerHour;
    }

    public double CalculatePay()
    {
        return HoursWorked * PayPerHour;
    }
}

class PermanentEmployee : Person, IPayable
{
    public double BasicSalary;

    public PermanentEmployee(string firstName, string lastName,
                             double basicSalary)
        : base(firstName, lastName)
    {
        BasicSalary = basicSalary;
    }

    public double CalculatePay()
    {
        double hra = BasicSalary * 0.15;
        double da = BasicSalary * 0.10;

        double totalPay = BasicSalary + hra + da;
        double tax = totalPay * 0.08;

        return totalPay - tax;
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("1. Hourly Employee");
        Console.WriteLine("2. Permanent Employee");
        Console.Write("Enter Choice: ");

        int choice = Convert.ToInt32(Console.ReadLine());

        if (choice == 1)
        {
            Console.Write("First Name: ");
            string first = Console.ReadLine();

            Console.Write("Last Name: ");
            string last = Console.ReadLine();

            Console.Write("Hours Worked: ");
            double hours = Convert.ToDouble(Console.ReadLine());

            Console.Write("Pay Per Hour: ");
            double rate = Convert.ToDouble(Console.ReadLine());

            HourlyEmployee emp = new HourlyEmployee(first, last, hours, rate);

            emp.Display();
            Console.WriteLine("Pay = " + emp.CalculatePay());
        }
        else if (choice == 2)
        {
            Console.Write("First Name: ");
            string first = Console.ReadLine();

            Console.Write("Last Name: ");
            string last = Console.ReadLine();

            Console.Write("Basic Salary: ");
            double salary = Convert.ToDouble(Console.ReadLine());

            PermanentEmployee emp = new PermanentEmployee(first, last, salary);

            emp.Display();
            Console.WriteLine("Net Pay = " + emp.CalculatePay());
        }
        else
        {
            Console.WriteLine("Invalid Choice");
        }
    }
}