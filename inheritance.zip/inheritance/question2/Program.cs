﻿using System;

class Person
{
    public string FirstName;
    public string LastName;
    public string Email;
    public DateTime DateOfBirth;

    public Person(string firstName, string lastName, string email, DateTime dob)
    {
        FirstName = firstName;
        LastName = lastName;
        Email = email;
        DateOfBirth = dob;
    }

    public void DisplayPerson()
    {
        Console.WriteLine("\nPerson Details");
        Console.WriteLine("-------------------------");
        Console.WriteLine("Name : " + FirstName + " " + LastName);
        Console.WriteLine("Email: " + Email);
        Console.WriteLine("DOB  : " + DateOfBirth.ToShortDateString());
    }
}

class HourlyEmployee : Person
{
    public double HoursWorked;
    public double PayPerHour;

    public HourlyEmployee(string firstName, string lastName, string email,
        DateTime dob, double hoursWorked, double payPerHour)
        : base(firstName, lastName, email, dob)
    {
        HoursWorked = hoursWorked;
        PayPerHour = payPerHour;
    }

    public double TotalPay()
    {
        return HoursWorked * PayPerHour;
    }

    public void DisplayHourlyEmployee()
    {
        DisplayPerson();
        Console.WriteLine("Hours Worked : " + HoursWorked);
        Console.WriteLine("Pay Per Hour : " + PayPerHour);
        Console.WriteLine("Total Pay    : " + TotalPay());
    }
}

class PermanentEmployee : Person
{
    public double BasicSalary;
    public double HRA;
    public double DA;
    public double Tax;
    public double NetPay;
    public double TotalPay;

    public PermanentEmployee(string firstName, string lastName, string email,
        DateTime dob, double basicSalary)
        : base(firstName, lastName, email, dob)
    {
        BasicSalary = basicSalary;

        HRA = BasicSalary * 0.15;
        DA = BasicSalary * 0.10;

        TotalPay = BasicSalary + HRA + DA;

        Tax = TotalPay * 0.08;

        NetPay = TotalPay - Tax;
    }

    public void DisplayPermanentEmployee()
    {
        DisplayPerson();

        Console.WriteLine("Basic Salary : " + BasicSalary);
        Console.WriteLine("HRA          : " + HRA);
        Console.WriteLine("DA           : " + DA);
        Console.WriteLine("Tax          : " + Tax);
        Console.WriteLine("Net Pay      : " + NetPay);
        Console.WriteLine("Total Pay    : " + TotalPay);
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("1. Hourly Employee");
        Console.WriteLine("2. Permanent Employee");
        Console.Write("Enter Choice: ");

        int choice = Convert.ToInt32(Console.ReadLine());

        Console.Write("First Name: ");
        string first = Console.ReadLine();

        Console.Write("Last Name: ");
        string last = Console.ReadLine();

        Console.Write("Email: ");
        string email = Console.ReadLine();

        Console.Write("DOB (dd/mm/yyyy): ");
        DateTime dob = DateTime.Parse(Console.ReadLine());

        if (choice == 1)
        {
            Console.Write("Hours Worked: ");
            double hours = Convert.ToDouble(Console.ReadLine());

            Console.Write("Pay Per Hour: ");
            double rate = Convert.ToDouble(Console.ReadLine());

            HourlyEmployee emp =
                new HourlyEmployee(first, last, email, dob, hours, rate);

            emp.DisplayHourlyEmployee();
        }
        else if (choice == 2)
        {
            Console.Write("Basic Salary: ");
            double salary = Convert.ToDouble(Console.ReadLine());

            PermanentEmployee emp =
                new PermanentEmployee(first, last, email, dob, salary);

            emp.DisplayPermanentEmployee();
        }
        else
        {
            Console.WriteLine("Invalid Choice");
        }
    }
}