﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.Write("Enter file name: ");
        string fileName = Console.ReadLine();

        Console.Write("Enter text to write into the file: ");
        string content = Console.ReadLine();

        StreamWriter writer = new StreamWriter(fileName + ".txt");

        writer.WriteLine(content);

        writer.Close();

        Console.WriteLine("File created and data saved successfully.");
    }
}