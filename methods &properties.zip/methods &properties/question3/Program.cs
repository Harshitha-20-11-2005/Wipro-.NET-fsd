﻿using System;

class RandomHelper
{
    static Random random = new Random();

    // Returns a random integer between min and max (inclusive)
    public static int RandInt(int min, int max)
    {
        return random.Next(min, max + 1);
    }

    // Returns a random double between min and max
    public static double RandDouble(int min, int max)
    {
        return min + random.NextDouble() * (max - min);
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Enter minimum value: ");
        int min = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter maximum value: ");
        int max = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("\nRandom Integer = " + RandomHelper.RandInt(min, max));
        Console.WriteLine("Random Double = " + RandomHelper.RandDouble(min, max));
    }
}