﻿using System;

class Program
{
    static void Main()
    {
        string correctUsername = "admin";
        string correctPassword = "1234";

        int attempts = 0;

        while (attempts < 3)
        {
            Console.Write("Enter Username: ");
            string username = Console.ReadLine();

            Console.Write("Enter Password: ");
            string password = Console.ReadLine();

            if (username == correctUsername && password == correctPassword)
            {
                Console.WriteLine("Login Successful");
                return;
            }
            else
            {
                attempts++;
                Console.WriteLine("Invalid Username or Password");

                if (attempts < 3)
                {
                    Console.WriteLine("Attempts Left: " + (3 - attempts));
                }
            }
        }

        Console.WriteLine("Access Denied. You have exceeded 3 attempts.");
    }
}